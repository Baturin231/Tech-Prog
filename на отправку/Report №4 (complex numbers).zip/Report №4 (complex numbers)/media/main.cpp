/*d = ((a+b+c)/(a-b+c))^2*/
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

struct complex {
    float Im;//мнимая
    float Re;//действительная
};

int main() {

    srand(time(NULL));
    const string name = "original.txt";

    ofstream wr(name);
    if (wr.is_open()) {
        complex abc[3];
        cout << "\tIm:\tRe:\n";
        for (int i = 0; i < 3; i++) {
            abc[i].Re = 1 + rand() % 9;
            //cin >> abc[i].Re >> abc[i].Im;
            abc[i].Im = rand() % 10;
            wr << abc[i].Re << "\t" << abc[i].Im << endl;
            cout << i+1 << ")\t" << abc[i].Re << "\t" << abc[i].Im << endl;
        }
        wr.close();
    } else{
        cout << "\nFailed to create a file\n";
        return -1;
    }

    ifstream rd(name);
    if (rd.is_open()) {
        complex abc[3], d, ch, zn;
        for (int i = 0; i < 3; i++)
            rd >> abc[i].Re >> abc[i].Im;
        rd.close();

        ch.Re = ch.Im = zn.Re = zn.Im = 0;

        for (int i = 0; i < 3; i++) {
            ch.Re += abc[i].Re;
            ch.Im += abc[i].Im;
        }

        zn.Re += abc[0].Re + abc[2].Re - abc[1].Re;
        zn.Im += abc[0].Im + abc[2].Im - abc[1].Im;

        ch.Re = (ch.Re*zn.Re + ch.Im*zn.Im)/(pow(zn.Re,2)+pow(zn.Im, 2));
        ch.Im = pow((ch.Im*zn.Re - ch.Re*zn.Im)/(pow(zn.Re,2)+pow(zn.Im, 2)),2);

        cout << "\nResult: " << ch.Re << " + " << ch.Im << "i\n";
    } else{
        cout << "\nCouldn't access the file\n";
        return -2;
    }

    return 0;
}