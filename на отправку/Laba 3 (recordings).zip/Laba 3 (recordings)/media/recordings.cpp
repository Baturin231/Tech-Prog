﻿#include <iostream>
#include <fstream>
using namespace std;

struct relax {
	char place[25];
	int month1, month2, month3;
	int price, income;
};

int main() {
	const int size = 5;
	const string data = "data.bin";

	ofstream f_bin(data, ios::binary);
	if (f_bin.is_open()) {
		relax holiday_before[size] = {
			{"Gelendzhik",250, 200, 190, 514, 0},
			{"Sochi",251, 201, 191, 511, 0},
			{"Adler",252, 202, 192, 512, 0},
			{"Krasnodar",253, 203, 193, 510, 0},
			{"Tuapse",254, 204, 194, 513, 0},
			{"Yalta", 255,205, 195, 516, 0},
			{"Anapa", 256,206, 196, 510, 0},
			{"Kazan", 257,207, 197, 518, 0},
			{"Rostov", 258,208, 198, 500, 0},
			{"Krasnodar", 259,209, 199, 520, 0}
		};

		for (int i = 0; i < size; i++) {
			f_bin.write((char*)&holiday_before[i].place, sizeof(holiday_before[i].place));
			f_bin.write((char*)&holiday_before[i].month1, sizeof(holiday_before[i].month1));
			f_bin.write((char*)&holiday_before[i].month2, sizeof(holiday_before[i].month2));
			f_bin.write((char*)&holiday_before[i].month3, sizeof(holiday_before[i].month3));
			f_bin.write((char*)&holiday_before[i].price, sizeof(holiday_before[i].price));
			f_bin.write((char*)&holiday_before[i].income, sizeof(holiday_before[i].income));
		}
		f_bin.close();
	}
	else cout << "\nNot access to bin 1.1\n";

	ifstream s_bin(data, ios::binary);
	if (s_bin.is_open()) {
		relax holiday_after[size];
		for (int i = 0; i < size; i++) {
			s_bin.read((char*)&holiday_after[i].place, sizeof(holiday_after[i].place));
			s_bin.read((char*)&holiday_after[i].month1, sizeof(holiday_after[i].month1));
			s_bin.read((char*)&holiday_after[i].month2, sizeof(holiday_after[i].month2));
			s_bin.read((char*)&holiday_after[i].month3, sizeof(holiday_after[i].month3));
			s_bin.read((char*)&holiday_after[i].price, sizeof(holiday_after[i].price));
			s_bin.read((char*)&holiday_after[i].income, sizeof(holiday_after[i].income));
		}
		s_bin.close();

		float sr = 0;
		for (int i = 0; i < size; i++) {
			holiday_after[i].income += (holiday_after[i].month1 + holiday_after[i].month2
				+ holiday_after[i].month3) * holiday_after[i].price;
			sr += holiday_after[i].price;
		}
		sr /= size;

		ofstream correction(data, ios::binary);
		if (correction.is_open()) {
			for (int i = 0; i < size; i++) {
				for (int j = 0; j < size; j++) {
					if (holiday_after[i].price < holiday_after[j].price) {
						swap(holiday_after[i].place, holiday_after[j].place);
						swap(holiday_after[i].month1, holiday_after[j].month1);
						swap(holiday_after[i].month2, holiday_after[j].month2);
						swap(holiday_after[i].month3, holiday_after[j].month3);
						swap(holiday_after[i].price, holiday_after[j].price);
						swap(holiday_after[i].income, holiday_after[j].income);
					}
				}
			}

			for (int i = 0; i < size; i++) {
				correction.write((char*)&holiday_after[i].place, sizeof(holiday_after[i].place));
				correction.write((char*)&holiday_after[i].month1, sizeof(holiday_after[i].month1));
				correction.write((char*)&holiday_after[i].month2, sizeof(holiday_after[i].month2));
				correction.write((char*)&holiday_after[i].month3, sizeof(holiday_after[i].month3));
				correction.write((char*)&holiday_after[i].price, sizeof(holiday_after[i].price));
				correction.write((char*)&holiday_after[i].income, sizeof(holiday_after[i].income));
			}
			correction.close();
		}
		else cout << "\nNot access to bin 1.3\n";


		cout << "Average by prices: " << sr
			<< "\n\nSorted matrixes of structures:\n";
		for (int i = 0; i < size; i++)
			cout << holiday_after[i].place << " "
			<< holiday_after[i].month1 << " "
			<< holiday_after[i].month2 << " "
			<< holiday_after[i].month3 << " "
			<< holiday_after[i].price << " "
			<< holiday_after[i].income << endl;

		ofstream result("Result.txt");
		if (result.is_open()) {
			result << "Average by prices: " << sr
				<< "\n\nSorted matrixes of structures:\n";
			for (int i = 0; i < size; i++) {
				result << holiday_after[i].place << " "
					<< holiday_after[i].month1 << " "
					<< holiday_after[i].month2 << " "
					<< holiday_after[i].month3 << " "
					<< holiday_after[i].price << " "
					<< holiday_after[i].income << endl;
			}
			result.close();
		}
		else cout << "\nNot access to txt 1.1\n";
	}
	else
		cout << "\nNot access to bin 1.2\n";

	return 0;
}