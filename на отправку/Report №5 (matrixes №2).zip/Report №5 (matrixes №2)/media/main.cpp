#include <iostream>
#include <fstream>
#include <complex>
using namespace std;

bool create_Bin(int size, const string name) {
    ofstream f_Bin(name);
    if (f_Bin.is_open()) {
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {
                complex<float> el;
                el.real(rand() % 10);
                el.imag(rand() % 10);
                f_Bin.write((char*)&el, sizeof(el));
            }

        f_Bin.close();
        return true;
    }
    else {
        cout << "Failed to create file " << name << "\n";
        return false;
    }
}

complex<float>** read(const string name, int size) {
    ifstream s_Bin(name);
    if (s_Bin.is_open()) {
        complex<float>** mat = new complex<float>*[size];
        for (int i = 0; i < size; i++) {
            mat[i] = new complex<float>[size];
            for (int j = 0; j < size; j++) {
                s_Bin.read((char*)&mat[i][j], sizeof(mat[i][j]));
            }
        }
        s_Bin.close();
        return mat;
    }
    else
        cout << "Failed to open file " << name << "\n";
}

void print_M(complex<float>** mat, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) cout << mat[i][j] << " ";
        cout << endl;
    }
}

void GetMatr(complex<float>** mas, complex<float>** p, int i, int j, int m) {
    int ki, kj, di, dj;
    di = 0;
    for (ki = 0; ki < m - 1; ki++) {
        if (ki == i) di = 1;
        dj = 0;
        for (kj = 0; kj < m - 1; kj++) {
            if (kj == j) dj = 1;
            p[ki][kj] = mas[ki + di][kj + dj];
        }
    }
}

complex<float> Determinant(complex<float>** mas, int m) {
    int n;
    complex<float> d, k;
    complex<float>** p;
    p = new complex<float>*[m];
    for (int i = 0; i < m; i++)
        p[i] = new complex<float>[m];
    int j = 0; d = 0;
    k.imag(1);
    k.real(1);
    n = m - 1;
    if (m < 1) cout << "Определитель вычислить невозможно!";
    if (m == 1) {
        d = mas[0][0];
        return(d);
    }
    if (m == 2) {
        d = mas[0][0] * mas[1][1] - (mas[1][0] * mas[0][1]);
        return(d);
    }
    if (m > 2) {
        for (int i = 0; i < m; i++) {
            GetMatr(mas, p, i, 0, m);
            d = d + k * mas[i][0] * Determinant(p, n);
            k = -k;
        }
    }
    return(d);
}

int main() {
    srand(time(NULL));

    const string bin_A = "A.bin", bin_B = "B.bin";
    int n, m;
    cout << "Enter size fo matrix A: "; cin >> n;
    cout << "Enter size fo matrix B: "; cin >> m;
    complex<float>** A = new complex<float> *[n], ** A_T = new complex<float> *[n],** B = new complex<float> *[m], ** C = new complex<float> *[n], d;

    for (int i1 = 0, i2 = 0; i1 < n, i2 < m; i1++, i2++) {
        A[i1] = new complex<float>[n];
        A_T[i1] = new complex<float>[n];
        B[i2] = new complex<float>[m];
        C[i1] = new complex<float>[n];
    }

    if (create_Bin(n, bin_A) && create_Bin(m, bin_B)) {
        A = read(bin_A, n);
        B = read(bin_B, m);
    }
    else
        return(create_Bin(n, bin_A));

    cout << "A:\n";
    print_M(A, n);
    cout << "\nB:\n";
    print_M(B, m);

    d = Determinant(B, m);
    cout << "\nDeterminant B: " << d << endl;

    cout << "\nC:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i][j] = d * A[i][j];
            cout << C[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}