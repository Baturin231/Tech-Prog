﻿//1. Найти самую короткую строку текста и заменить ее фразой «Happy new year!».
//необходимые условия для алгоритма: пробел в начале каждого предложения. если самое короткое предложение находится в конце, то отсутствие у него восклицательного знака
//'!' считывается также как '.', на выборке вариантов ввода считывается печатать только на английском. Вариация с Y ещё не завершена до конца, поэтому там отображается только поле введите текст, но ввести ничего нельзя
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct check { int kol = 0, position = 0; };

struct remember { int mn, begin, end; };

int main() {

	const string txt = "Text.txt", txt2 = "buffer.txt";
	ifstream print_text(txt), numb_offers(txt), positions_offers(txt), replacement_short1(txt);
	ofstream replacement_short2(txt2);
	string change = "HAPPY NEW YEAR!", str, choose;
	bool flag = false; char symbol;
	int position = 1, counter_offers = 0;

	cout << "Do u want enter your text?(Y/N)  "; cin >> choose;
	if (choose == "N" || choose == "n" || choose == "no" || choose == "No" || choose == "NO") cout << "\nOk, I'm using ready text\n";

	if (choose == "Y" || choose == "y" || choose == "yes" || choose == "Yes" || choose == "YES") {
		cout << "\nEnter text\n*be sure to put punctuation marks at the end of each sentence\n";
		str = "This picture is very beautiful. I like it. It was drawn my very good friend? Nice, nice, it's really very beatiful.";
		ofstream create_file(txt);
		if (create_file.is_open()) {
			create_file << " " << str;
			create_file.close();
		}
		else cout << "Don't get create file with text\n";
	}


	if (numb_offers.is_open()) {
		while (!numb_offers.eof()) {
			numb_offers.get(symbol);
			if (symbol == '.' || symbol == '?') counter_offers++;
		}
		counter_offers--;
		numb_offers.close();
	}
	else cout << "Not access to file 1.1\n";

	check* offers = new check[counter_offers];
	if (positions_offers.is_open()) {
		int i = 0;
		while (!positions_offers.eof() && i < counter_offers) {
			positions_offers.get(symbol);
			if (symbol == '.' || symbol == '?') offers[i].position = position; i++; continue;

			if (symbol == ' ' || symbol == '\t') offers[i].kol++;
			position++;
		}
		positions_offers.close();
	}
	else cout << "Not access to file 1.2\n";

	//для beg position + 1, для end исходные данные подходят 
	remember strt; strt.mn = offers[0].kol;
	strt.begin = 0; strt.end = 0;
	for (int i = 1; i < counter_offers; i++) {
		if (offers[i].kol < strt.mn && offers[i].kol != 0) {
			strt.mn = offers[i].kol;
			strt.begin += offers[i - 1].position + 1;
			strt.end += offers[i].position;
		}
	}

	if (replacement_short1.is_open() && replacement_short2.is_open()) {
		position = 0;
		while (!replacement_short1.eof()) {
			position++;
			replacement_short1.get(symbol);
			if (position >= strt.begin + 1 && position <= strt.end && flag == false) {
				replacement_short2 << change;
				flag = true;
			}
			else replacement_short2 << symbol;
		}
		replacement_short1.close();
		replacement_short2.close();
	}
	else cout << "Not access to file 1.3 || 2.1\n";

	if (flag) cout << "\nReady successfully\n";
	else cout << "Not successful";
	return 0;
}