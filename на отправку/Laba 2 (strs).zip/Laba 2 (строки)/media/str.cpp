﻿#include <iostream>
#include <fstream>
#include <windows.h>
#include <string>
using namespace std;

struct remember { int mn, position; };

int main() {

	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	const string txt = "Text.txt", txt2 = "Ready.txt";
	ifstream print_text(txt), changer(txt), kol_s(txt); ofstream changered(txt2);
	string change = "HAPPY NEW YEAR!", str, choose;
	bool flag = false; char symbol;
	int counter_strs = 1;remember mn;

	cout << "Do u want enter your text?(Y/N)  "; cin >> choose;
	if (choose == "N" || choose == "n")
		cout << "\nOk, I'm using ready text\n";

	if (choose == "Y" || choose == "y") {
		cout << "\nEnter text\n*be sure to press Enter at the end of each string\n";
		str = "This picture is very beautiful.\n
		 I like it.\n It was drawn my very good friend?\n
		  Nice, nice, it's really very beatiful.";
		ofstream create_file(txt);
		if (create_file.is_open()) {
			create_file << " " << str;
			create_file.close();
		}
		else cout << "Don't get create file with text\n";
	}

	if (print_text.is_open()) {
		cout << "\nPrint's text:\n";
		while (!print_text.eof()) {
			print_text.get(symbol);
			cout << symbol;
			if (symbol == '\n') counter_strs++;
		}
		cout << endl;
		print_text.close();
	}
	else cout << "\nNot access to text 1.0\n";

	int* kol_symbols = new int[counter_strs];
	for (int i = 0; i < counter_strs; i++)kol_symbols[i] = 0;

	if(kol_s.is_open()){
		int i = 0;
		while (!kol_s.eof()) {
			kol_s.get(symbol);
			if (symbol == '\n')i++;
			else kol_symbols[i]++;
		}

		mn.mn = kol_symbols[0]; mn.position = 0;
		for (int i = 1; i < counter_strs; i++)
			if (kol_symbols[i] < mn.mn) {
				mn.mn = kol_symbols[i];
				mn.position = i;
			}

		kol_s.close();
	}
	else cout << "\nNot access to text 1.1\n";

	if (changer.is_open()) {
		if (changered.is_open()) {
			counter_strs = 0;
			while (!changer.eof()) {
				changer.get(symbol);
				if (symbol == '\n') {
					counter_strs++;
					changered << '\n';
				}

				else {
					if (counter_strs == mn.position && flag == false) {
						changered << " " << change;
						flag = true;
					}
					if (counter_strs != mn.position) changered << symbol;
				}
			}
			changered.close();
		}
		else cout << "\nNot access to text 2.0\n";
		changer.close();
	}
	else cout << "\nNot access to text 1.1\n";

	if (flag) cout << "\nReady successfully\n";
	else cout << "Not successful";
	
	return 0;
}