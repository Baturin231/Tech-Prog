﻿/*
В двумерном массиве B, состоящем из n×n целых чисел вычислить:
1) произведение элементов;
2) индексы наибольшего четного элемента;
3) сумму чисел-палиндромов, расположенных вне диагоналей матрицы.
4) для заданной матрицы размерности B(n×n) и матрицы того же типа и размерности С(n×n) найти значение выражения  A=С⋅B-B^T
*/
#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

int main() {

	srand(time(NULL));

	const string Txt1 = "1st matrix.txt";
	const string Txt2 = "2nd matrix.txt";
	const string Bin1 = "1st matrix.bin";
	const string Bin2 = "2nd matrix.bin";
	const string Result = "Result.txt";

	int n, pr = 1, sum = 0; ; cout << "Enter size of matrixes: "; cin >> n;
	ofstream t_FmatrixB(Txt1), t_FmatrixС(Txt2), b_FmatrixB(Bin1, ios::binary), b_FmatrixC(Bin2, ios::binary);
	ifstream t_SmatrixB(Txt1), t_SmatrixC(Txt2), b_SmatrixB(Bin1, ios::binary), b_SmatrixC(Bin2, ios::binary);
	bool flag[3] = { false, false, false };

	if (t_FmatrixB.is_open() && t_FmatrixС.is_open()) {
		flag[0] = true;
		int** B_Before = new int* [n], ** C_Before = new int* [n];
		for (int i = 0; i < n; i++) { B_Before[i] = new int[n]; C_Before[i] = new int[n]; }

		cout << "\nMatrix B before txt:\n";
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				B_Before[i][j] = 1 + rand() % 9;
				t_FmatrixB << B_Before[i][j] << " ";
				cout << B_Before[i][j] << " ";
				C_Before[i][j] = 1 + rand() % 9;
				t_FmatrixС << C_Before[i][j] << " ";
			}
			cout << endl; t_FmatrixB << endl; t_FmatrixС << endl;
		}

		cout << "\nMatrix C before txt:\n";
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				cout << C_Before[i][j] << " ";
			}
			cout << endl;
		}

		for (int i = 0; i < n; i++) { delete[] B_Before[i]; delete[] C_Before[i]; }
		delete[] B_Before;
		t_FmatrixB.close(); t_FmatrixС.close();
	}
	else cout << "No access txt 1.0 or 2.0\n";

	if (t_SmatrixB.is_open() && t_SmatrixC.is_open() && b_FmatrixB.is_open() && b_FmatrixC.is_open()) {
		int el; flag[1] = true;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				t_SmatrixB >> el;
				b_FmatrixB.write((char*)&el, sizeof(el));
				t_SmatrixC >> el;
				b_FmatrixC.write((char*)&el, sizeof(el));
			}

		t_SmatrixB.close(); t_SmatrixC.close(); b_FmatrixB.close(); b_FmatrixC.close();
	}
	else cout << "No access to txt 1.1 or 2.1 or bin 1.0 or bin 2.0\n";

	if (b_SmatrixB.is_open() && b_SmatrixC.is_open()) {
		flag[2] = true;
		int** B_After = new int* [n], ** C_After = new int* [n], ** ending = new int* [n], ** B_T = new int* [n];
		for (int i = 0; i < n; i++) { B_After[i] = new int[n]; C_After[i] = new int[n]; B_T[i] = new int[n]; ending[i] = new int[n]; }
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				b_SmatrixB.read((char*)&B_After[i][j], sizeof(B_After[i][j]));
				b_SmatrixC.read((char*)&C_After[i][j], sizeof(C_After[i][j]));
			}

//перемножение всех элементов
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				pr *= B_After[i][j];
			}
		}

//индексы элементов
		int chMX = B_After[0][0], I, J;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (B_After[i][j] % 2 == 0 && B_After[i][j] > chMX) {
					chMX = B_After[i][j];
					I = i; J = j;
				}
			}
		}

//прикол с палиндромами
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i != j && i + j != n - 1) {
					int chislo1 = B_After[i][j], kolCH = 0;
					while (chislo1) {
						kolCH++;
						chislo1 /= 10;
					}

					int* massiv = new int[kolCH];
					int chislo2 = B_After[i][j];
					for (int k = 0; k < kolCH; k++) {
						massiv[k] = chislo2 % 10;
						chislo2 /= 10;
					}

					int chislo3 = 0;
					for (int k = 0; k < kolCH / 2; k++)
						if (massiv[k] == massiv[kolCH - k - 1])
							chislo3++;

					if (chislo3 == kolCH / 2)
						sum += B_After[i][j];
				}
			}
		}

//по формуле A = C*B-B^T
		//сложение матриц
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				ending[i][j] = 0;
				for (int k = 0; k < n; k++)
					ending[i][j] += C_After[i][k] * B_After[k][j];
			}

		//транспонирование
		for (int i = 0; i < n; i++)for (int j = 0; j < n; j++) B_T[i][j] = B_After[i][j];
		for (int i = 0; i < n; i++)for (int j = i; j < n; j++)swap(B_T[i][j], B_T[j][i]);
		
		//конечная
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				ending[i][j] - B_T[i][j];
			}
		}
		
		cout << "\nComposition: " << pr << endl
			<< "Indexs of max even:" << I << " " << J << endl
			<< "Sum of palindrome numbers: " << sum << endl
			<< "Get's matrix A:\n";

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				cout << ending[i][j] << " ";
			cout << endl;
		}

//запись в 3й файл
		if (flag[0] && flag[1] && flag[2]) {
			ofstream F_Result(Result);
			if (F_Result.is_open()) {
				F_Result << "Composition: " << pr << endl
					<< "Indexs of max even:" << I << " " << J << endl
					<< "Sum of palindrome numbers: " << sum << endl
					<< "Get's matrix A:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) F_Result << ending[i][j] << " ";
					F_Result << endl;
				}
				F_Result.close();
			}
		}
		b_SmatrixB.close(); b_SmatrixC.close();
	}
	else cout << "No access to bin 1.1 or bin 2.1\n";

	return 0;
}