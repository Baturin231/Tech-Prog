﻿/*В матрице вещественных чисел D(n×m):
найти и вывести номера строк, упорядоченных по убыванию; 
Сформировать вектор С(m×2) из максимальных и минимальных значений столбцов матрицы.*/
#include <iostream>
#include <fstream>
#include <ctime>
#include <vector>
using namespace std;

struct mnmx {
	float mn, mx;
};

int main() {
	srand(time(NULL));

	const string txt = "matrix.txt";
	const string bin = "matrix.bin";
	const string result = "Result.txt";
	
	ofstream t_FmatrixD(txt), b_FmatrixD(bin, ios::binary);
	ifstream t_SmatrixD(txt), b_SmatrixD(bin, ios::binary);

	int n, m; cout << "Enter size of matrix:\n";
	cout << "Enter kol str: "; cin >> n;
	cout << "Enter kol klmn: "; cin >> m;
	vector <mnmx> C(m);

	if (t_FmatrixD.is_open()) {
		float** D_Before = new float* [n];
		for (int i = 0; i < n; i++) 
			D_Before[i] = new float[m];

		cout << "\nEnter matrix B in txt:\n";
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cin >> D_Before[i][j];
				t_FmatrixD << D_Before[i][j] << " ";
			}
			t_FmatrixD << endl;
		}

		t_FmatrixD.close();
		for (int i = 0; i < n; i++) 
			delete[] D_Before[i];
		delete[] D_Before;
	}
	else cout << "\nNo access txt 1.0\n";

	if (t_SmatrixD.is_open() && b_FmatrixD.is_open()) {
		for (int i = 0, el; i < n; i++)
			for (int j = 0; j < m; j++) {
				t_SmatrixD >> el;
				b_FmatrixD.write((char*)&el, sizeof(el));
			}

		t_SmatrixD.close(); b_FmatrixD.close();
	}
	else 
		cout << "\nNo access to txt 1.1 or bin 1.0\n";

	if (b_SmatrixD.is_open()) {
		float** D_After = new float* [n];
		for (int i = 0; i < n; i++) 
			D_After[i] = new float[m];

		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
				b_SmatrixD.read((char*)&D_After[i][j], 
					sizeof(D_After[i][j]));
		b_SmatrixD.close();

//минимальные и максимальные столбцов
		for (int j = 0; j < m; j++) {
			float mn = D_After[0][j];
			float mx = D_After[0][j];
			C[j].mn = C[j].mx = mn;
			for (int i = 0; i < n; i++){
				if (mn > D_After[i][j]) {
					mn = D_After[i][j];
					C[j].mn = mn;
				}

				if (mx < D_After[i][j]) {
					mx = D_After[i][j];
					C[j].mx = mx;
				}
			}
		}
//номера строк, упорядоченных по убыванию;
		int size = 0;
		for (int i = 0; i < n; i++) {
			int kol = 0;
			for (int j = 1; j < m; j++) {
				if (D_After[i][j] < D_After[i][j - 1]) 
					kol++;
			}
			if (kol == m - 1)
				size++;
		}

		float* res = new  float[size];
		for (int i = 0, z = 0; i < n; i++) {
			int kol = 0;
			for (int j = 1; j < m; j++) {
				if (D_After[i][j] < D_After[i][j - 1])
					kol++;
			}
			if (kol == m - 1) {
				res[z] = i;
				z++;
			}
		}
//Запись итогов в файл
		ofstream Result(result);
		if (Result.is_open()) {
			Result << "get's matrix D:\n";
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < m; j++)
					Result << D_After[i][j] << " ";
				Result << "\n";
			}
			Result << "\nNumbers str, ordered in descending order:\n";
			for (int i = 0; i < size; i++)
				Result << res[i] << " ";
			Result << "\n\nVector C:\nColumn minimums: ";
			for (int j = 0; j < m; j++)
				Result << C[j].mn << " ";
			Result << "\nColumn maximums: ";
			for (int j = 0; j < m; j++)
				Result << C[j].mx << " ";
			Result.close();
		}
		else 
			cout << "\nNo access to file with results\n";
	}
	
	else 
		cout << "\nNo access to bin 1.1\n";

	return 0;
}