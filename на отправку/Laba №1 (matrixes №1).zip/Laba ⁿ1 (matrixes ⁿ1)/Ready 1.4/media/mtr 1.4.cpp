﻿#include <iostream>
#include <fstream>
#include <cmath>
#include <ctime>
#include <chrono>
using namespace std;
using namespace std::chrono;

const string tA = "mA.txt", tC = "mC.txt",
bA = "mA.bin", bC = "mC.bin",
t_masA = "masA.txt", t_masC = "masB.txt",
b_masA = "masA.bin", b_masC = "masB.bin";

bool create_TXT(int n, string type) {
	srand(time(NULL));
	if (type != "mas") {
		ofstream f_tA(tA), f_tC(tC);
		if (f_tA.is_open() && f_tC.is_open()) {
			if (n <= 30) {
				int el;
				cout << "\nEnter matrix A:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						el = 1 + rand() % 10;//cin >> el;
						cout << el << " ";//
						f_tA << el << " ";
					}
					cout << endl;//
					f_tA << endl;
				}
				f_tA.close();

				cout << "\nEnter matrix C:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						el = 1 + rand() % 10;//cin >> el;
						cout << el << " ";//
						f_tC << el << " ";
					}
					cout << endl;//
					f_tC << endl;
				}
			}

			else {
				int el;
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						el = 1 + rand() % 10;
						f_tA << el << " ";
					}
					f_tA << endl;
				}
				f_tA.close();

				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						el = 1 + rand() % 10;
						f_tC << el << " ";
					}
					f_tC << endl;
				}
			}
			f_tC.close();
			return true;
		}

		else {
			cout << "\nDon't get create txt for matrixes A&C\n";
			return false;
		}
	}
	else {
		ofstream f_tAmas(t_masA), f_tCmas(t_masC);
		if (f_tAmas.is_open() && f_tCmas.is_open()) {
			if (n <= 30) {
				int el;
				cout << "\nEnter massif A:\n";
				for (int i = 0; i < n; i++) {
					el = 1 + rand() % 10;//cin >> el;
					cout << el << " ";//
					f_tAmas << el << " ";
				}
				f_tAmas.close();

				cout << "\nEnter massif C:\n";
				for (int i = 0; i < n; i++) {
					el = 1 + rand() % 10;//cin >> el;
					cout << el << " ";//
					f_tCmas << el << " ";
				}
				f_tCmas.close();
			}

			else {
				int el;
				for (int i = 0; i < n; i++) {
					el = 1 + rand() % 10;//cin >> el;
					f_tAmas << el << " ";
				}
				f_tAmas.close();

				for (int i = 0; i < n; i++) {
					el = 1 + rand() % 10;//cin >> el;
					f_tCmas << el << " ";
				}
				f_tCmas.close();
			}
			return true;
		}

		else {
			cout << "\nDon't get create txt for massives A&C\n";
			return false;
		}
	}
}

bool create_BIN(int n, string type) {
	if (type != "mas") {
		ofstream f_bA(bA, ios::binary), f_bC(bC, ios::binary);
		ifstream s_tA(tA), s_tC(tC);
		if (f_bA.is_open() && f_bC.is_open()) {
			if (s_tA.is_open() && s_tC.is_open()) {
				int el;
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						s_tA >> el;
						f_bA.write((char*)&el, sizeof(el));
						s_tC >> el;
						f_bC.write((char*)&el, sizeof(el));
					}
				}
				s_tA.close(), s_tC.close(), f_bA.close(), f_bC.close();
				return true;
			}
			else {
				cout << "\nDon't get access to txt matrixes A&C\n";
				return false;
			}
		}

		else {
			cout << "\nDon't get create bin for matrixes A&C\n";
			return false;
		}
	}

	else {
		ofstream f_bAmas(b_masA, ios::binary), f_bCmas(b_masC, ios::binary);
		ifstream s_tAmas(t_masA), s_tCmas(t_masC);
		if (f_bAmas.is_open() && f_bCmas.is_open()) {
			if (s_tAmas.is_open() && s_tCmas.is_open()) {
				int el;
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						s_tAmas >> el;
						f_bAmas.write((char*)&el, sizeof(el));
						s_tCmas >> el;
						f_bCmas.write((char*)&el, sizeof(el));
					}
				}
				s_tAmas.close(), s_tCmas.close(), f_bAmas.close(), f_bCmas.close();
				return true;
			}
			else {
				cout << "\nDon't get access to txt massives A&C\n";
				return false;
			}
		}

		else {
			cout << "\nDon't get create bin for matrixes A&C\n";
			return false;
		}
	}
}

void reading(int** mat, int n, const string name) {
	ifstream bin(name, ios::binary);
	if (bin.is_open()) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				bin.read((char*)&mat[i][j], sizeof(mat[i][j]));
			}
		}
		bin.close();
	}
	else
		cout << "\nDon't get access to bin matrixes A&C\n";

}
void reading_mas(int* mat, int n, const string name) {
	ifstream bin(name, ios::binary);
	if (bin.is_open()) {
		for (int i = 0; i < n; i++)
			bin.read((char*)&mat[i], sizeof(mat[i]));
		bin.close();
	}
	else
		cout << "\nDon't get access to bin massives A&C\n";
}

void print_matrix(int** matrix, int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			cout << matrix[i][j] << " ";
		cout << endl;
	}
}
void print_mas(int* mas, int Un2, int Un1) {
	for (int i = 0; i < Un2; i++) {
		if (i % Un1 == 0)
			cout << endl;
		cout << mas[i] << " ";
	}
	cout << endl;
}

void multiplication_mat(int** A, int** B, int** C, int n, string choose) {
	if (choose == "IJK") {
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				B[i][j] = 0;
				for (int k = 0; k < n; k++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	if (choose == "IKJ") {
		for (int i = 0; i < n; i++)
			for (int k = 0; k < n; k++) {
				B[i][k] = 0;
				for (int j = 0; j < n; j++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	if (choose == "JIK") {
		for (int j = 0; j < n; j++)
			for (int i = 0; i < n; i++) {
				B[j][i] = 0;
				for (int k = 0; k < n; k++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	if (choose == "JKI") {
		for (int j = 0; j < n; j++)
			for (int k = 0; k < n; k++) {
				B[j][k] = 0;
				for (int i = 0; i < n; i++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	if (choose == "KIJ") {
		for (int k = 0; k < n; k++)
			for (int i = 0; i < n; i++) {
				B[k][i] = 0;
				for (int j = 0; j < n; j++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	if (choose == "KJI") {
		for (int k = 0; k < n; k++)
			for (int j = 0; j < n; j++) {
				B[k][j] = 0;
				for (int i = 0; i < n; i++)
					B[i][j] += A[i][k] * C[k][j];
			}
	}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			B[i][j] = 0;
			for (int k = 0; k < n; k++)
				B[i][j] += A[i][k] * C[k][j];
		}

	if (n <= 30) {
		cout << "\nMultiplication matrixes " << choose << ":\n";
		print_matrix(B, n);
	}
}
void multiplication_mas(int* A, int* B, int* C, int Un1, int Un2, string choose) {
	if(choose == "IJK")
	for (int i = 0; i < Un1; i++)
		for (int j = 0; j < Un1; j++) {
			B[i * Un1 + j] = 0;
			for (int k = 0; k < Un1; k++)
				B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
		}

	if (choose == "IKJ")
		for (int i = 0; i < Un1; i++)
			for (int k = 0; k < Un1; k++) {
				B[i * Un1 + k] = 0;
				for (int j = 0; j < Un1; j++)
					B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
			}

	if (choose == "JIK")
		for (int j = 0; j < Un1; j++)
			for (int i = 0; i < Un1; i++) {
				B[j * Un1 + i] = 0;
				for (int k = 0; k < Un1; k++)
					B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
			}

	if (choose == "JKI")
		for (int j = 0; j < Un1; j++)
			for (int k = 0; k < Un1; k++) {
				B[j * Un1 + k] = 0;
				for (int i = 0; i < Un1; i++)
					B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
			}

	if (choose == "KIJ")
		for (int k = 0; k < Un1; k++)
			for (int i = 0; i < Un1; i++) {
				B[k * Un1 + i] = 0;
				for (int j = 0; j < Un1; j++)
					B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
			}

	if (choose == "KJI")
		for (int k = 0; k < Un1; k++)
			for (int j = 0; j < Un1; j++) {
				B[k * Un1 + j] = 0;
				for (int i = 0; i < Un1; i++)
					B[i * Un1 + j] += A[i * Un1 + k] * C[k * Un1 + j];
			}

	if (Un1 <= 30) {
		cout << "\nMultiplication massifs:";
		print_mas(B, Un2, Un1);
	}
}

int main() {
	int Un1, Un2, n500 = 500, n1000 = 1000, n2000 = 2000;
	cout << "I)\nEnter size of matrixes A&C:\t";
	cin >> Un1; Un2 = Un1 * Un1;

	if (create_TXT(Un1, "mat") && create_BIN(Un1, "mat")) {
		int** mat_A = new int* [Un1], ** mat_C = new int* [Un1], ** mat_B = new int* [Un1];
		for (int i = 0; i < Un1; i++) {
			mat_A[i] = new int[Un1];
			mat_C[i] = new int[Un1];
			mat_B[i] = new int[Un1];
		}

		reading(mat_A, Un1, bA);
		reading(mat_C, Un1, bC);

		ofstream result("result.txt");
		if (result.is_open()) {
			result << "I)\nOriginal matrix A:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_A[i][j] << " ";
				result << endl;
			}

			result << "\nOriginal matrix C:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_C[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "IJK");
			result << "\nMultiplication matrixes IJK:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "IKJ");
			result << "\nMultiplication matrixes IKJ:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "JIK");
			result << "\nMultiplication matrixes JIK:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "JKI");
			result << "\nMultiplication matrixes JKI:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "KIJ");
			result << "\nMultiplication matrixes KIJ:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}

			multiplication_mat(mat_A, mat_B, mat_C, Un1, "KJI");
			result << "\nMultiplication matrixes KJI:\n";
			for (int i = 0; i < Un1; i++) {
				for (int j = 0; j < Un1; j++)
					result << mat_B[i][j] << " ";
				result << endl;
			}
		}
		else
			cout << "\nFailed to create txt with results 1.1\n";
	}
	else
		cout << "\nFailed to create txt or bin 1.1\n";


	if (create_TXT(n500, "mat") && create_BIN(n500, "mat")) {
		int** mat_A = new int* [n500], ** mat_C = new int* [n500], ** mat_B = new int* [n500];
		for (int i = 0; i < n500; i++) {
			mat_A[i] = new int[n500];
			mat_C[i] = new int[n500];
			mat_B[i] = new int[n500];
		}

		reading(mat_A, n500, bA);
		reading(mat_C, n500, bC);

		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "\nII)\n";
			result << "\tIJK IKJ JIK JKI KIJ KJI\n";
			result << "500:  ";

			cout << "\nII)\n";
			cout << "\tIJK\tIKJ\tJIK\tJKI\tKIJ\tKJI\n";
			cout << "500:\t";

			auto timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n500, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
		}
		else
			cout << "\nNo access to txt with results 1.2\n";
	}
	else
		cout << "\nNo access to txt or bin 1.2\n";

	if (create_TXT(n1000, "mat") && create_BIN(n1000, "mat")) {
		int** mat_A = new int* [n1000], ** mat_C = new int* [n1000], ** mat_B = new int* [n1000];
		for (int i = 0; i < n1000; i++) {
			mat_A[i] = new int[n1000];
			mat_C[i] = new int[n1000];
			mat_B[i] = new int[n1000];
		}

		reading(mat_A, n1000, bA);
		reading(mat_C, n1000, bC);

		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "1000: ";
			cout << "1000:\t";

			auto timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n1000, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
		}
		else
			cout << "\nNo access to txt with results 1.3\n";
	}
	else
		cout << "\nNo access to txt or bin 1.3\n";

	if (create_TXT(n2000, "mat") && create_BIN(n2000, "mat")) {
		int** mat_A = new int* [n2000], ** mat_C = new int* [n2000], ** mat_B = new int* [n2000];
		for (int i = 0; i < n2000; i++) {
			mat_A[i] = new int[n2000];
			mat_C[i] = new int[n2000];
			mat_B[i] = new int[n2000];
		}

		reading(mat_A, n2000, bA);
		reading(mat_C, n2000, bC);

		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "2000:";
			cout << "2000:\t";
			auto timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mat(mat_A, mat_B, mat_C, n2000, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
		}
		else
			cout << "\nNo access to txt with results 1.4\n";
	}
	else
		cout << "\nNo access to txt or bin 1.4\n";

	cout << "\nIII)";
	if (create_TXT(Un2, "mas") && create_BIN(Un2, "mas")) {
		int* mas_A = new int[Un2], * mas_C = new int[Un2], * mas_B = new int[Un2];
		reading_mas(mas_A, Un2, b_masA);
		reading_mas(mas_C, Un2, b_masC);
		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "\nIII)\n";
			result << "Original massif A:";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_A[i] << " ";
			}
			result << endl;
			result << "\nOriginal massif C:";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_C[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IJK");
			result << "\nMultiplication matrixes IJK:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IKJ");
			result << "\nMultiplication matrixes IKJ:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JIK");
			result << "\nMultiplication matrixes JIK:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JKI");
			result << "\nMultiplication matrixes JKI:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KIJ");
			result << "\nMultiplication matrixes KIJ:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;

			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KJI");
			result << "\nMultiplication matrixes KJI:\n";
			for (int i = 0; i < Un2; i++) {
				if (i % Un1 == 0)
					result << endl;
				result << mas_B[i] << " ";
			}
			result << endl;
			result.close();
		}
		else
			cout << "\nNo access to txt with results 2.1\n";
	}
	else
		cout << "\nFailed to create txt or bin 2.1\n";

	Un1 = 500; Un2 = Un1 * Un1;
	if (create_TXT(Un1, "mas") && create_BIN(Un1, "mas")) {
		int* mas_A = new int[Un2], * mas_C = new int[Un2], * mas_B = new int[Un2];
		reading_mas(mas_A, Un2, b_masA);
		reading_mas(mas_C, Un2, b_masC);
		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "\n\tIJK IKJ JIK JKI KIJ KJI\n";
			result << "500:\t";

			cout << "\tIJK\tIKJ\tJIK\tJKI\tKIJ\tKJI\n";
			cout << "500:\t";

			auto timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";

			result.close();
			delete[]mas_A, delete[]mas_B, delete[]mas_C;
		}
		else
			cout << "\nNo access to txt with results 2.2\n";
	}
	else
		cout << "\nNo access to txt or bin 2.2\n";

	Un1 = 1000; Un2 = Un1 * Un1;
	if (create_TXT(Un1, "mas") && create_BIN(Un1, "mas")) {
		int* mas_A = new int[Un2], * mas_C = new int[Un2], * mas_B = new int[Un2];
		reading_mas(mas_A, Un2, b_masA);
		reading_mas(mas_C, Un2, b_masC);
		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "1000:\t";
			cout << "1000:\t";

			auto timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";

			result.close();
			delete[]mas_A, delete[]mas_B, delete[]mas_C;
		}
		else
			cout << "\nNo access to txt with results 2.3\n";
	}
	else
		cout << "\nNo access to txt or bin 2.3\n";

	Un1 = 2000; Un2 = Un1 * Un1;
	if (create_TXT(Un1, "mas") && create_BIN(Un1, "mas")) {
		int* mas_A = new int[Un2], * mas_C = new int[Un2], * mas_B = new int[Un2];
		reading_mas(mas_A, Un2, b_masA);
		reading_mas(mas_C, Un2, b_masC);
		ofstream result("result.txt", ios::app);
		if (result.is_open()) {
			result << "2000: ";
			cout << "2000: ";

			auto timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IJK");
			auto timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "IKJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JIK");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "JKI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KIJ");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\t";

			timeNULL = high_resolution_clock::now();
			multiplication_mas(mas_A, mas_B, mas_C, Un1, Un2, "KJI");
			timeONE = high_resolution_clock::now();
			result << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";
			cout << duration_cast<milliseconds>(timeONE - timeNULL).count() / 1000 << "\n";

			result.close();
			delete[]mas_A, delete[]mas_B, delete[]mas_C;
		}
		else
			cout << "\nNo access to txt with results 2.4\n";
	}
	else
		cout << "\nNo access to txt or bin 2.4\n";
	
	return 0;
}