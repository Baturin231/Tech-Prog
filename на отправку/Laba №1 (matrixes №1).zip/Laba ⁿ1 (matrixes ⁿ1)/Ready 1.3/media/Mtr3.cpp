﻿//Заданы матрицы A(n×n) и B(n×n). Найти определитель матрицы С=В^Т⋅A
#include <iostream>
#include <fstream>
using namespace std;

void Print_Matrix(int** matrix, int size) {
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++)
			cout << matrix[i][j] << " ";
		cout << endl;
	}
}

void Get_Matrix(int** matrix, int** p, int i, int j, int size) {
	int di = 0;
	for (int ki = 0; ki < size - 1; ki++) {
		if (ki == i) di = 1;
		int dj = 0;
		for (int kj = 0; kj < size - 1; kj++) {
			if (kj == j) dj = 1;
			p[ki][kj] = matrix[ki + di][kj + dj];
		}
	}
}
// Рекурсивное вычисление определителя
int Determinant(int** matrix, int size) {
	int j = 0, d = 0, k = 1, n = size - 1;
	int** p = new int* [size];
	for (int i = 0; i < size; i++)
		p[i] = new int[size];

	if (size < 1) cout << "\nthe determinant cannot be calculated\n";
	if (size == 1) {
		d = matrix[0][0];
		return(d);
	}
	if (size == 2) {
		d = matrix[0][0] * matrix[1][1] -(matrix[1][0] * matrix[0][1]);
		return(d);
	}
	if (size > 2) {
		for (int i = 0; i < size; i++) {
			Get_Matrix(matrix, p, i, 0, size);
			d = d + k * matrix[i][0] * Determinant(p, n);
			k = -k;
		}
	}
	return(d);
}

int main() {

	srand(time(NULL));

	const string Txt1 = "1st matrix.txt";
	const string Txt2 = "2nd matrix.txt";
	const string Bin1 = "1st matrix.bin";
	const string Bin2 = "2nd matrix.bin";
	const string result = "Result.txt";

	int n, determinant_C; cout << "Enter size of matrixes: "; cin >> n;
	ofstream t_FmatrixB(Txt1), t_FmatrixA(Txt2), b_FmatrixB(Bin1, ios::binary), 
		b_FmatrixA(Bin2, ios::binary);
	ifstream t_SmatrixB(Txt1), t_SmatrixA(Txt2), b_SmatrixB(Bin1, ios::binary), 
		b_SmatrixA(Bin2, ios::binary);

	if (t_FmatrixB.is_open() && t_FmatrixA.is_open()) {
		int** B_Before = new int* [n], ** A_Before = new int* [n];
		for (int i = 0; i < n; i++) { 
			B_Before[i] = new int[n]; 
			A_Before[i] = new int[n];
			for (int j = 0; j < n; j++) {
				B_Before[i][j] = 1 + rand() % 9;
				t_FmatrixB << B_Before[i][j] << " ";
				A_Before[i][j] = 1 + rand() % 9;
				t_FmatrixA << A_Before[i][j] << " ";
			}
			t_FmatrixB << endl; t_FmatrixA << endl;
		}

		t_FmatrixB.close(); t_FmatrixA.close();
		for (int i = 0; i < n; i++) { delete[] B_Before[i]; delete[] A_Before[i]; }
		delete[] B_Before, A_Before;
	}
	else cout << "No access txt (1.0 or 2.0)\n";

	if (t_SmatrixB.is_open() && t_SmatrixA.is_open() && b_FmatrixB.is_open() && b_FmatrixA.is_open()) {
		int el;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				t_SmatrixB >> el;
				b_FmatrixB.write((char*)&el, sizeof(el));
				t_SmatrixA >> el;
				b_FmatrixA.write((char*)&el, sizeof(el));
			}

		t_SmatrixB.close(); t_SmatrixA.close(); b_FmatrixB.close(); b_FmatrixA.close();
	}
	else cout << "No access to txt (1.1 or 2.1) or bin (1.0 or 2.0)\n";

	if (b_SmatrixB.is_open() && b_SmatrixA.is_open()) {
		int** B_After = new int* [n], ** A_After = new int* [n], ** C = new int* [n];
		for (int i = 0; i < n; i++) { 
			B_After[i] = new int[n]; A_After[i] = new int[n]; 
			C[i] = new int[n]; 
			for (int j = 0; j < n; j++) {
				b_SmatrixB.read((char*)&B_After[i][j], sizeof(B_After[i][j]));
				b_SmatrixA.read((char*)&A_After[i][j], sizeof(A_After[i][j]));
			}
		}

		cout << "\nMatrix A after bin:\n";
		Print_Matrix(A_After, n);
		cout << "\nMatrix B after bin:\n";
		Print_Matrix(B_After, n);

		for (int i = 0; i < n; i++)for (int j = i; j < n; j++)
			swap(B_After[i][j], B_After[j][i]);
				
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				C[i][j] = 0;
				for (int k = 0; k < n; k++)
					C[i][j] += A_After[i][k] * B_After[k][j];
			}
		determinant_C = Determinant(C, n);

		cout << "\nGet's matrix C:\n";
		Print_Matrix(C, n);
		cout << "\nDeterminant matrix C: " << determinant_C << endl;

			ofstream F_Result(result);
			if (F_Result.is_open()) {
				F_Result << "Original matrix A:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) F_Result << A_After[i][j] << " ";
					F_Result << endl;
				}
				F_Result << "\nOriginal matrix B:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) F_Result << B_After[i][j] << " ";
					F_Result << endl;
				}
				F_Result << "\nGet's matrix C:\n";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) F_Result << C[i][j] << " ";
					F_Result << endl;
				}
				F_Result << "\nGet's determinant of matrix C: " << determinant_C;
				F_Result.close();
			}

		b_SmatrixB.close(); b_SmatrixA.close();
		for (int i = 0; i < n; i++) { delete[] B_After[i], A_After[i], C; }
		delete[] B_After, A_After, C;
	}
	else cout << "No access to bin 1.1 or bin 2.1\n";

	return 0;
}